from flask import Flask,render_template,request
import pyodbc
from math import sin, cos, sqrt, atan2, radians
import datetime

conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:rishi1310.database.windows.net,1433;Database=rishi;Uid=adminrishi;Pwd=13101996@Ri$hi;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=45;;')
cr = conn.cursor()

query="select * from all_month"
result = cr.execute(query)
data = result.fetchall()

app = Flask(__name__)

@app.route("/")
def task1():
    return render_template("task1.html")

@app.route("/search_mag", methods=["GET", "POST"])
def search_mag():
    formdata = dict(request.form)
    mag1 = formdata['mag']
    cr.execute("SELECT * FROM all_month where mag > ? and lower(type)='earthquake'", mag1)
    res = cr.fetchall()
    if(len(res)<1):
        flag=0
    else:
        flag=1
    return render_template("result1.html", data=res, flag=flag, mag=mag1, count=len(res))

@app.route("/task2")
def task2():
    return render_template("task2.html")

@app.route("/mag_date", methods=["GET", "POST"])
def mag_date():
    formdata = dict(request.form)
    mag1 = formdata['mag1']
    mag2 = formdata['mag2']
    date1 = formdata['date1']
    date2 = formdata['date2']
    cr.execute("select * from all_month where mag > ? and mag < ? and convert(nvarchar, time ,10) between ? and ?", mag1, mag2, date1, date2)
    res = cr.fetchall()
    if(len(res)<1):
        flag=0
    else:
        flag=1
    return render_template("result2.html", data=res, flag=flag)

def distance(la1,lon1, la2, lon2):
    # approximate radius of earth in km
    R = 6373.0
    lati1 = radians(la1)
    loni1 = radians(lon1)
    lati2 = radians(la2)
    loni2 = radians(lon2)
    dlon = loni2 - loni1
    dlat = lati2 - lati1
    a = sin(dlat / 2)**2 + cos(lati1) * cos(lati2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c
    return distance

@app.route("/task3")
def task3():
    return render_template("task3.html")

@app.route("/calc_dist", methods=["GET", "POST"])
def calc_dist():
    formdata = dict(request.form)
    lati1 = float(formdata['lat1'])
    loni1 = float(formdata['lon1'])
    disit = float(formdata['dist'])

    result = cr.execute("select * from all_month where lower(type)='earthquake'")
    data = result.fetchall()

    res = list()
    for d in data:
        dis = int(distance(lati1,loni1,d[1],d[2]))
        if dis <= disit :
            res.append(d)    
    return render_template("result3.html", data=res, count=len(res))

@app.route("/task4")
def task4():
    return render_template("task4.html")

@app.route("/cluster", methods=["GET", "POST"])
def cluster():
    formdata = dict(request.form)
    dati =  datetime.datetime.strptime(formdata['datee'], "%Y-%m-%d")
    dat1 = dati + datetime.timedelta(days=1)
    result = cr.execute("select * from all_month where convert(nvarchar, time ,10) between ? and ? and type='earthquake'",dati,dat1)
    res = result.fetchall()
    return render_template("result4.html", data=res, count=len(res))


    
if __name__ == '__main__':
    app.debug = True
    app.run()