from flask import Flask,render_template,request
import pyodbc
import random
import time
from pymongo import MongoClient
import redis
import hashlib

##connecting to Azure mysql 
conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=tcp:rishi1310.database.windows.net,1433;Database=rishi;Uid=adminrishi;Pwd=13101996@Ri$hi;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=45;;')
cr = conn.cursor()

##connecting to Azure mongodb
mongoconnect=MongoClient("mongodb://rishimongodb:eUG0rI3XiFhMTZxkLdBf9ssSHiNq5rpexmKcR52vo34fkCfltkRi1KnHlnwup67E1YtQNV7ijqB5UmZQp7u1Sg==@rishimongodb.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false&replicaSet=globaldb&maxIdleTimeMS=120000&appName=@rishimongodb@")

db=mongoconnect["all_month"]
mycol = db["earthquakes"]

##connecting to Azure Redis
hostname = "rishiredis.redis.cache.windows.net"
pswd = "LPSkBpMZfGQrpAKTQNNtvxneGmGIz2oYVAzCaNAAYE0="
redis_cache = redis.StrictRedis(host=hostname,port=6380,password=pswd,ssl=True)
re = redis_cache.ping()
print("Ping returned : " + str(re))

app = Flask(__name__)

@app.route("/")
def task1():
    return render_template("task1.html")

@app.route("/result1", methods=["GET", "POST"])
def result1():
    formdata = dict(request.form)
    magi1 = int(formdata['mag1'])
    magi2 = int(formdata['mag2'])
    n = int(formdata['n'])  
    opti = request.form.get('opt')

    if(opti=='1'):
        start = time.time()
        for i in range(0,n):
            magi=random.randrange(magi1, magi2)
            cr.execute("select * from all_month where mag =?",magi)
            res = cr.fetchall()
        toe = time.time() - start

    elif(opti=='2'):
        toe = 0
        for i in range(0,n):
            magi = random.randrange(magi1, magi2)
            query = f"select * from all_month where mag>{magi}"
            hash = hashlib.sha224(query.encode('utf-8')).hexdigest()
            if (redis_cache.get(hash)):
                print(f"cached value {i}") 
                start=time.time()               
                data = redis_cache.get(hash)
                toe = toe+ (time.time()-start)
                print("fetched from cache")
            else:
                start = time.time()
                res = cr.execute(query)
                data = res.fetchall()
                redis_cache.set(hash, len(data))
                redis_cache.expire(hash,30) 
                toe = toe+ (time.time() - start)                   
                print("fetched from db")
        print(toe)
    elif(opti=='3'):
        doc=list()
        start = time.time()
        for i in range(0,n):
            magi=random.randrange(magi1, magi2)
            result = mycol.find({'mag': {'$gte': str(magi) }})
            #for d in result:
               #doc.append(d)                
        toe = time.time() - start
    return render_template("result1.html", noq = n, toe = toe, opt=opti)

@app.route("/task2")
def task2():
    return render_template("task2.html")

@app.route("/result2", methods=["GET", "POST"])
def result2():
    formdata = dict(request.form)
    mag1 = int(formdata['mag1'])
    mag2 = int(formdata['mag2'])
    n = int(formdata['n'])  
    locsrc= formdata['locsrc']
    opt = request.form.get('opt')

    if(opt=='1'):
        start = time.time()
        for i in range(0,n):
            mag=random.randrange(mag1, mag2)
            cr.execute("select * from all_month where mag =? and locationSource=?",mag,locsrc)
            res = cr.fetchall()
        toe = time.time() - start

    elif(opt=='2'):
        toe = 0
        for i in range(0,n):
            mag = random.randrange(mag1, mag2)
            query = f"select * from all_month where mag>{mag} and locationSource={locsrc}"
            hash = hashlib.sha224(query.encode('utf-8')).hexdigest()
            if (redis_cache.get(hash)):
                print(f"cached value {i}") 
                start=time.time()               
                data = redis_cache.get(hash)
                toe = toe+ (time.time()-start)
                print("fetched from cache")
            else:
                start = time.time()
                cr.execute("select * from all_month where mag =? and locationSource=?",mag,locsrc)
                data = cr.fetchall()
                redis_cache.set(hash, len(data))
                redis_cache.expire(hash,30) 
                toe = toe+ (time.time() - start)                   
                print("fetched from db")
        print(toe)
    elif(opt=='3'):
        doc=list()
        start = time.time()
        for i in range(0,n):
            mag=random.randrange(mag1, mag2)
            result = mycol.find({"locationSource": {locsrc}, 'mag': {'$gte': str(mag) } })
            #for d in result:
               #doc.append(d)                
        toe = time.time() - start
    return render_template("result2.html", noq = n, toe = toe, opt=opt)
