Name:Priyanka Wakte
cse 6331-Advance Database
Assignment-04


Link:
https://assignment-priyanka0878.azurewebsites.net/

Run app.py in Python version 3.9