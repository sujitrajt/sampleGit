from flask import Flask, request, render_template
import csv
import os


# reading csv file
filenm = "people.csv"
data = list()
with open(filenm, 'r') as csvfile:  
    csvreader = csv.reader(csvfile)  
    fields = next(csvreader)
    for row in csvreader:
        rowdata = dict() 
        rowdata['name'] = row[0].lower()
        rowdata['state'] = row[1]
        rowdata['salary'] = row[2]
        rowdata['grade'] = row[3]
        rowdata['room'] = row[4]
        rowdata['telenum'] = row[5]
        rowdata['pic'] = row[6]
        rowdata['keywords'] = row[7]
        data.append(rowdata)
print("CSV file successfully loaded")

#path for images
PICTURES_FOLDER = os.path.join('static','images')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = PICTURES_FOLDER

@app.route("/")
def home():
    return render_template("index.html",data=data)

@app.route("/selectname")
def selectname():
    return render_template("selectname.html")  

@app.route("/submit", methods=["GET", "POST"])
def submit():
    formdata = dict(request.form)
    name = formdata['name']
    for d in data:
        if(name.lower() == d['name'].lower() and not len(d['pic'])<3): 
            pic = d['pic']
            break
        else:
            pic="PICTURE NOT FOUND"   
    print(pic)
    if(pic!="PICTURE NOT FOUND"):
        picture = os.path.join(app.config['UPLOAD_FOLDER'], pic)
        flag=0
    else:
        picture="PICTURE NOT FOUND"  
        flag=1  
    print("picture final: "+picture)
    return render_template("displaypic.html", user_image = picture, flag=flag ) 

@app.route("/selectsal")
def selectsal():
    return render_template("selectsal.html")  

@app.route("/displaysal", methods=["GET", "POST"])
def displaysal():
    formdata = dict(request.form)
    print(formdata)
    fromsal = formdata['from'] 
    tosal = formdata['to'] 

    img_list = list()
    for r in data:
        if (r['salary']!=' ' and r['salary']!='' and len(r['salary'])!=0 and r['salary']!=None):
            sal = r['salary']
        else:
            sal = int(0)  
        if(int(sal)>=int(fromsal) and int(sal)<=int(tosal)):
            img= dict()
            img['name']=r['name']
            img['salary']=sal
            if not len(r['pic'])<2 :
                img['pic']=os.path.join(app.config['UPLOAD_FOLDER'], r['pic'])
            else:
                img['pic'] = 'Image not available'
            img_list.append(img)   
    print(img_list)     
    return render_template("displaysal.html", image_list=img_list)

@app.route("/uploadpic")
def uploadpic():
    return render_template("uploadpic.html", data=data)

@app.route("/upload", methods=["GET", "POST"])
def upload():
    formdata = dict(request.form)
    print(formdata)
    print(request)
    print(request.files.get)

    uploaded_file = request.files.get('imgfile', None)
    name = formdata['name'].lower()
    file = request.files['imgfile'].filename
    if file != '':
        uploaded_file.save(app.config['UPLOAD_FOLDER']+"\\"+file)
    
    datavalues=list()
    for dat in data:
        l=list()
        l = list(dat.values())
        datavalues = datavalues+l
        
    for d in data:
        if name==d['name']:
            if file not in datavalues:
                d['pic']=file
                flag=0
                break
            else:
                flag=1
        else:
            flag=1

    return render_template("upload.html", data=data, flag=flag)

@app.route("/deleterec")
def deleterec():
    return render_template("deleterec.html", data=data)

@app.route("/delete", methods=["GET", "POST"])
def delete():
    formdata = dict(request.form)
    print(formdata)
    name = formdata['name'].lower() 
    for d in data:
        if(d['name']==name):
            data.remove(d)
            break
            flag=0
        else:
            flag=1
    return render_template("delete.html",data=data)

@app.route("/editrec")
def editrec():
    return render_template("editrec.html", data=data)

@app.route("/edit", methods=["GET", "POST"])
def edit():
    formdata = dict(request.form)
    print(formdata)
    name = formdata['name'].lower() 
    att = formdata['att'].lower()
    val = formdata['value'].lower()
    for d in data:
        if(d['name']==name):
            if(att in list(d.keys())):
                d[att]=val
                flag=0
                break
            else:
                flag=1
        else:
            flag=1
    return render_template("edit.html",data=data)
